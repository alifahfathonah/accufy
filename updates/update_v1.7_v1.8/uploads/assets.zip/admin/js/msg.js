

(function($) {
  "use strict";

      var msg_opps = $('.msg_opps').val(); 
      var msg_error = $('.msg_error').val();
      var msg_sorry = $('.msg_sorry').val();
      var msg_try_again = $('.msg_try_again').val();

});